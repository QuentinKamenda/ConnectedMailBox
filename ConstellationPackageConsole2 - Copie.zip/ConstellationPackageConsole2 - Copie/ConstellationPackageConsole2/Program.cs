﻿using Constellation;
using Constellation.Package;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.IO;
using System.Timers;

namespace ConstellationPackageConsole2
{
    public class Program : PackageBase
    {
        private double tampon_antepenultieme = 0;                               // initialisation de la variable qui contiendra l'antépénultième  poids dans la boite aux lettres 
        private double reference_poid = 0;                                        // ancien poids validé par le package (on l'initialise juste)

        private Random rnd = new Random();


        [StateObjectLink("BalancePackage", "Balance")]            // On tape "stateobjectlink" puis Tab Tab pour l'autocomplétion du code
        public StateObjectNotifier Balance { get; set; }                    // Ca récupère le State Object (si on veut etre precis: "Sentinel", "Package", "name")

        static void Main(string[] args)
        {
            PackageHost.Start<Program>(args);
        }

        public override void OnStart()
        {
            PackageHost.WriteInfo("Package starting - IsRunning: {0} - IsConnected: {1}", PackageHost.IsRunning, PackageHost.IsConnected);
            string lol = @"/home/pi/Documents/FileCamera/photo/5.jpg";
            PackageHost.WriteInfo($"le nom est {lol.Remove(0, 35)}");
            tampon_antepenultieme = 0;
            this.Balance.ValueChanged += Balance_ValueChanged;              // On regarde quand la valeur dans CPU change (= évêvnement).
        }

        static string uri_image()
        {
            string[] liste_fichier = Directory.GetFiles(@"/home/pi/Documents/FileCamera/photo", "*");
            while (liste_fichier.Length == 0)
            {
                liste_fichier = Directory.GetFiles(@"/home/pi/Documents/FileCamera/photo", "*");
            }
            PackageHost.WriteInfo($"le nom de l'image est {liste_fichier[0]}");
            return liste_fichier[0];
        }

        static void ranger_image()
        {

            PackageHost.WriteInfo("je suis dans ranger_image");
            string fichier_destination = @"/home/pi/Documents/FileCamera/photo/archive";
            PackageHost.WriteInfo($"le chemin existe: {Directory.Exists(fichier_destination)}");
            if (!Directory.Exists(fichier_destination))
            {
                DirectoryInfo di = Directory.CreateDirectory(@"/home/pi/Documents/FileCamera/photo/archive");
            }
            string nom_image = uri_image();
            PackageHost.WriteInfo("le nom est" + nom_image.Remove(0, 35));
            string adresse_destination = fichier_destination + nom_image.Remove(0, 35);
            PackageHost.WriteError( "olol" + adresse_destination);
            File.Move(@"/home/pi/Documents/FileCamera/photo/1.jpg", adresse_destination);
            string chemin_image = "file:///home/pi/Documents/FileCamera/photo/archive";
            chemin_image = chemin_image + nom_image.Remove(0, 35);
            PackageHost.WriteError("l'uri est " + chemin_image);
            PackageHost.SendMessage(MessageScope.Create("PushBullet"), "PushFile", new object[] { chemin_image as System.String, "la puissance" as System.String });

        }

        static void renomer()
        {
            PackageHost.WriteError("je suis rentre dans renomer negro");
            int num_photo = 10;
            string directory = @"/home/pi/Documents/FileCamera/photo/archive";
           
            int i = 0;
            if (File.Exists(directory + @"/" + num_photo.ToString() + ".jpg"))
            {
                File.Delete(directory + @"/" + num_photo.ToString() + ".jpg");
            }
            
            var fileCount = (from file in Directory.EnumerateFiles(directory, "*.jpg", SearchOption.AllDirectories) select file).Count();
            
            while (i < (fileCount))
            {
                
                System.IO.File.Move(directory + @"/" + (fileCount - i).ToString() + ".jpg", directory + @"/" + (fileCount + 1 - i).ToString() + ".jpg");

                i++;
          
            }
            PackageHost.WriteError("je sors de renomer  negro");


            int j = 0;
            if (File.Exists(directory + @"/" + num_photo.ToString() + ".txt"))
            {
                File.Delete(directory + @"/" + num_photo.ToString() + ".txt");
            }

            var fileCount2 = (from file in Directory.EnumerateFiles(directory, "*.txt", SearchOption.AllDirectories) select file).Count();

            while (j < (fileCount2))
            {

                System.IO.File.Move(directory + @"/" + (fileCount2 - j).ToString() + ".txt", directory + @"/" + (fileCount2 + 1 - j).ToString() + ".txt");

                j++;

            }
            PackageHost.WriteError("je sors de renomer  negro");
        }


        private void Balance_ValueChanged(object sender, StateObjectChangedEventArgs e)
        {

            PackageHost.WriteInfo("kikoo");
            double Seuil_lettre = PackageHost.GetSettingValue<double>("Seuil_lettre");         // stocke la valeur du poids de la lettre réglé par l'utilisateur (ou par la valeur par défaut)
            double Seuil_magazine = PackageHost.GetSettingValue<double>("Seuil_magazine");     // stocke la valeur du poids du magazine réglé par l'utilisateur (ou par la valeur par défaut)
            double Seuil_colis = PackageHost.GetSettingValue<double>("Seuil_colis");           // stocke la valeur du poids du colis réglé par l'utilisateur (ou par la valeur par défaut)
            bool enable_photo= PackageHost.GetSettingValue<bool>("enable_photo");

            double delta = PackageHost.GetSettingValue<double>("delta");                      // stocke la valeur de l'erreur toléré réglé par l'utilisateur ( ou par la valeur par défaut)


            if (e.IsNew)
            {
                tampon_antepenultieme = e.NewState.DynamicValue.Value;                                 // on garde la première valeur comme tampon de référence
                reference_poid = tampon_antepenultieme;                                          // on garde la première valeur comme poids de référence
                PackageHost.WriteInfo("Beuh!");
            }
            else
            {
                PackageHost.WriteInfo($"Current: {e.NewState.DynamicValue.Value}");
                if ((e.NewState.DynamicValue.Value <= e.OldState.DynamicValue.Value + delta && e.NewState.DynamicValue.Value >= e.OldState.DynamicValue.Value - delta) && (e.NewState.DynamicValue.Value <= tampon_antepenultieme + delta && e.NewState.DynamicValue.Value >= tampon_antepenultieme - delta) && (e.NewState.DynamicValue.Value < reference_poid - delta || e.NewState.DynamicValue.Value > reference_poid + delta))
                /* rentre dans la boucle si et seulement si: 
                 *  la nouvelle valeur du poids est similaire aux deux précédentes (plus ou moins l'erreur tolérer, celle d'avant étant oldstate et l'antépénultième étant tampon_antepenultieme)
                 */
                {
                    PackageHost.WriteInfo("c'est stable");
                    /*
                     * on  rentre dans l'un des "if" en fonction des seuils réglés par l'utilisateur, le reste du programme étant le même juste l'ordre change
                     */
                    if (Seuil_colis >= Seuil_magazine && Seuil_magazine > Seuil_lettre)
                    {
                        PackageHost.WriteInfo($"je suis rentré dans le bon truc et la reference poids est {reference_poid} et la différence de poids {e.NewState.DynamicValue.Value - reference_poid} et le seuil colis de {Seuil_colis}");

                        if (e.NewState.DynamicValue.Value - reference_poid >= Seuil_colis) // contient l'instruction lorsque la différence entre le nouveau poids correspond à l'ajout d'un colis
                        {
                            PackageHost.WriteInfo("Vous avez reçus un colis");
                            reference_poid = e.NewState.DynamicValue.Value;
                            if (enable_photo)
                            {
                                try
                                {

                                    PackageHost.SendMessage(MessageScope.Create("PackCamera"), "TakePhoto", null);
                                    renomer();

                                    DateTime Now = DateTime.Now;

                                    string[] lines = { "Photo prise le " + Now.Day + "/" + Now.Month + "/" + Now.Year, "à " + Now.Hour + ":" + Now.Minute + ":" + Now.Second, "Poids :" + e.NewState.DynamicValue.Value + "XXX,XX" + "g" };

                                    File.WriteAllLines(@"/home/pi/Documents/FileCamera/photo/1.txt", lines);

                                    ranger_image();
                                }
                                catch
                                {
                                    PackageHost.WriteError("Votre caméra n'est pas brancher ou le package n'est pas installé");
                                }
                            }
                        }
                        else if (e.NewState.DynamicValue.Value - reference_poid >= Seuil_magazine) // contient l'instruction lorsque la différence entre le nouveau poids correspond à l'ajout d'un magazine
                        {
                            PackageHost.WriteError("Vous avez reçus un magazine");
                            reference_poid = e.NewState.DynamicValue.Value;
                            if (enable_photo)
                            {
                                try
                                {
                                    PackageHost.CreateMessageProxy("PackCamera").TakePhoto();
                                    ranger_image();
                                }
                                catch
                                {
                                    PackageHost.WriteError("Votre caméra n'est pas brancher ou le package n'est pas installé");
                                }
                            }
                        }
                        else if (e.NewState.DynamicValue.Value - reference_poid >= Seuil_lettre)  // contient l'instruction lorsque la différence entre le nouveau poids correspond à l'ajout d'une lettre
                        {
                            PackageHost.WriteDebug("Vous avez reçus une lettre");
                            reference_poid = e.NewState.DynamicValue.Value;
                            if (enable_photo)
                            {
                                try
                                {
                                    PackageHost.CreateMessageProxy("PackCamera").TakePhoto();
                                    ranger_image();
                                }
                                catch
                                {
                                    PackageHost.WriteError("Votre caméra n'est pas brancher ou le package n'est pas installé");
                                }
                            }
                        }
                        else if (e.NewState.DynamicValue.Value - reference_poid < 0) // contient l'instruction lorsque la différence entre le nouveau poids correspond au retrait d'une partie du courrier
                        {
                            PackageHost.WriteDebug("Du courrier a été retiré");
                            reference_poid = e.NewState.DynamicValue.Value;

                        }
                    }
                    else if (Seuil_colis > Seuil_lettre && Seuil_lettre >= Seuil_magazine)
                    {
                        if (e.NewState.DynamicValue.Value - reference_poid >= Seuil_colis)
                        {
                            PackageHost.WriteInfo("Vous avez reçus un colis");
                            reference_poid = e.NewState.DynamicValue.Value;
                            if (enable_photo)
                            {
                                try
                                {
                                    PackageHost.CreateMessageProxy("PackCamera").TakePhoto();
                                }
                                catch
                                {
                                    PackageHost.WriteError("Votre caméra n'est pas brancher ou le package n'est pas installé");
                                }
                            }
                        }
                        else if (e.NewState.DynamicValue.Value - reference_poid >= Seuil_lettre)
                        {
                            PackageHost.WriteError("Vous avez reçus un magazine");
                            reference_poid = e.NewState.DynamicValue.Value;
                            if (enable_photo)
                            {
                                try
                                {
                                    PackageHost.CreateMessageProxy("PackCamera").TakePhoto();
                                }
                                catch
                                {
                                    PackageHost.WriteError("Votre caméra n'est pas brancher ou le package n'est pas installé");
                                }
                            }
                        }
                        else if (e.NewState.DynamicValue.Value - reference_poid >= Seuil_magazine)
                        {
                            PackageHost.WriteDebug("Vous avez reçus une lettre");
                            reference_poid = e.NewState.DynamicValue.Value;
                            if (enable_photo)
                            {
                                try
                                {
                                    PackageHost.CreateMessageProxy("PackCamera").TakePhoto();
                                }
                                catch
                                {
                                    PackageHost.WriteError("Votre caméra n'est pas brancher ou le package n'est pas installé");
                                }
                            }
                        }
                        else if (e.NewState.DynamicValue.Value - reference_poid < 0)
                        {
                            PackageHost.WriteDebug("Du courrier a été retiré");
                            reference_poid = e.NewState.DynamicValue.Value;
                        }
                    }
                    else if (Seuil_magazine > Seuil_colis && Seuil_colis >= Seuil_lettre)
                    {
                        if (e.NewState.DynamicValue.Value - reference_poid >= Seuil_magazine)
                        {
                            PackageHost.WriteInfo("Vous avez reçus un colis");
                            reference_poid = e.NewState.DynamicValue.Value;
                            if (enable_photo)
                            {
                                try
                                {
                                    PackageHost.CreateMessageProxy("PackCamera").TakePhoto();
                                }
                                catch
                                {
                                    PackageHost.WriteError("Votre caméra n'est pas brancher ou le package n'est pas installé");
                                }
                            }
                        }
                        else if (e.NewState.DynamicValue.Value - reference_poid >= Seuil_colis)
                        {
                            PackageHost.WriteError("Vous avez reçus un magazine");
                            reference_poid = e.NewState.DynamicValue.Value;
                            if (enable_photo)
                            {
                                try
                                {
                                    PackageHost.CreateMessageProxy("PackCamera").TakePhoto();
                                }
                                catch
                                {
                                    PackageHost.WriteError("Votre caméra n'est pas brancher ou le package n'est pas installé");
                                }
                            }
                        }
                        else if (e.NewState.DynamicValue.Value - reference_poid >= Seuil_lettre)
                        {
                            PackageHost.WriteDebug("Vous avez reçus une lettre");
                            reference_poid = e.NewState.DynamicValue.Value;
                            if (enable_photo)
                            {
                                try
                                {
                                    PackageHost.CreateMessageProxy("PackCamera").TakePhoto();
                                }
                                catch
                                {
                                    PackageHost.WriteError("Votre caméra n'est pas brancher ou le package n'est pas installé");
                                }
                            }
                        }
                        else if (e.NewState.DynamicValue.Value - reference_poid < 0)
                        {
                            PackageHost.WriteDebug("Du courrier a été retiré");
                            reference_poid = e.NewState.DynamicValue.Value;
                        }
                    }
                    else if (Seuil_magazine > Seuil_lettre && Seuil_lettre >= Seuil_colis)
                    {
                        if (e.NewState.DynamicValue.Value - reference_poid >= Seuil_magazine)
                        {
                            PackageHost.WriteInfo("Vous avez reçus un colis");
                            reference_poid = e.NewState.DynamicValue.Value;
                            if (enable_photo)
                            {
                                try
                                {
                                    PackageHost.CreateMessageProxy("PackCamera").TakePhoto();
                                }
                                catch
                                {
                                    PackageHost.WriteError("Votre caméra n'est pas brancher ou le package n'est pas installé");
                                }
                            }
                        }
                        else if (e.NewState.DynamicValue.Value - reference_poid >= Seuil_lettre)
                        {
                            PackageHost.WriteError("Vous avez reçus un magazine");
                            reference_poid = e.NewState.DynamicValue.Value;
                            if (enable_photo)
                            {
                                try
                                {
                                    PackageHost.CreateMessageProxy("PackCamera").TakePhoto();
                                }
                                catch
                                {
                                    PackageHost.WriteError("Votre caméra n'est pas brancher ou le package n'est pas installé");
                                }
                            }
                        }
                        else if (e.NewState.DynamicValue.Value - reference_poid >= Seuil_colis)
                        {
                            PackageHost.WriteDebug("Vous avez reçus une lettre");
                            reference_poid = e.NewState.DynamicValue.Value;
                            if (enable_photo)
                            {
                                try
                                {
                                    PackageHost.CreateMessageProxy("PackCamera").TakePhoto();
                                }
                                catch
                                {
                                    PackageHost.WriteError("Votre caméra n'est pas brancher ou le package n'est pas installé");
                                }
                            }
                        }
                        else if (e.NewState.DynamicValue.Value - reference_poid < 0)
                        {
                            PackageHost.WriteDebug("Du courrier a été retiré");
                            reference_poid = e.NewState.DynamicValue.Value;
                        }
                    }
                    else if (Seuil_lettre > Seuil_magazine && Seuil_magazine >= Seuil_colis)
                    {
                        if (e.NewState.DynamicValue.Value - reference_poid >= Seuil_lettre)
                        {
                            PackageHost.WriteInfo("Vous avez reçus un colis");
                            reference_poid = e.NewState.DynamicValue.Value;
                            if (enable_photo)
                            {
                                try
                                {
                                    PackageHost.CreateMessageProxy("PackCamera").TakePhoto();
                                }
                                catch
                                {
                                    PackageHost.WriteError("Votre caméra n'est pas brancher ou le package n'est pas installé");
                                }
                            }
                        }
                        else if (e.NewState.DynamicValue.Value - reference_poid >= Seuil_magazine)
                        {
                            PackageHost.WriteError("Vous avez reçus un magazine");
                            reference_poid = e.NewState.DynamicValue.Value;
                            if (enable_photo)
                            {
                                try
                                {
                                    PackageHost.CreateMessageProxy("PackCamera").TakePhoto();
                                }
                                catch
                                {
                                    PackageHost.WriteError("Votre caméra n'est pas brancher ou le package n'est pas installé");
                                }
                            }
                        }
                        else if (e.NewState.DynamicValue.Value - reference_poid >= Seuil_colis)
                        {
                            PackageHost.WriteDebug("Vous avez reçus une lettre");
                            reference_poid = e.NewState.DynamicValue.Value;
                            if (enable_photo)
                            {
                                try
                                {
                                    PackageHost.CreateMessageProxy("PackCamera").TakePhoto();
                                }
                                catch
                                {
                                    PackageHost.WriteError("Votre caméra n'est pas brancher ou le package n'est pas installé");
                                }
                            }
                        }
                        else if (e.NewState.DynamicValue.Value - reference_poid < 0)
                        {
                            PackageHost.WriteDebug("Du courrier a été retiré");
                            reference_poid = e.NewState.DynamicValue.Value;
                        }
                    }
                    else if (Seuil_lettre > Seuil_colis && Seuil_colis > Seuil_magazine)
                    {
                        if (e.NewState.DynamicValue.Value - reference_poid >= Seuil_lettre)
                        {
                            PackageHost.WriteInfo("Vous avez reçus un colis");
                            reference_poid = e.NewState.DynamicValue.Value;
                            if (enable_photo)
                            {
                                try
                                {
                                    PackageHost.CreateMessageProxy("PackCamera").TakePhoto();
                                }
                                catch
                                {
                                    PackageHost.WriteError("Votre caméra n'est pas brancher ou le package n'est pas installé");
                                }
                            }
                        }
                        else if (e.NewState.DynamicValue.Value - reference_poid >= Seuil_colis)
                        {
                            PackageHost.WriteError("Vous avez reçus un magazine");
                            reference_poid = e.NewState.DynamicValue.Value;
                            if (enable_photo)
                            {
                                try
                                {
                                    PackageHost.CreateMessageProxy("PackCamera").TakePhoto();
                                }
                                catch
                                {
                                    PackageHost.WriteError("Votre caméra n'est pas brancher ou le package n'est pas installé");
                                }
                            }
                        }
                        else if (e.NewState.DynamicValue.Value - reference_poid >= Seuil_magazine)
                        {
                            PackageHost.WriteDebug("Vous avez reçus une lettre");
                            reference_poid = e.NewState.DynamicValue.Value;
                            if (enable_photo)
                            {
                                try
                                {
                                    PackageHost.CreateMessageProxy("PackCamera").TakePhoto();
                                }
                                catch
                                {
                                    PackageHost.WriteError("Votre caméra n'est pas brancher ou le package n'est pas installé");
                                }
                            }
                        }
                        else if (e.NewState.DynamicValue.Value - reference_poid < 0)
                        {
                            PackageHost.WriteDebug("Du courrier a été retiré");
                            reference_poid = e.NewState.DynamicValue.Value;
                        }
                    }
                    else if (Seuil_colis == Seuil_lettre && Seuil_lettre == Seuil_magazine)
                    {
                        if(e.NewState.DynamicValue.Value-reference_poid<0)
                        {
                            PackageHost.WriteDebug("Du courrier a été retiré");
                            reference_poid = e.NewState.DynamicValue.Value;
                        }
                        else
                        {
                            PackageHost.WriteDebug("Vous avez reçus du courrier ");
                            reference_poid = e.NewState.DynamicValue.Value;
                            if (enable_photo)
                            {
                                try
                                {
                                    PackageHost.CreateMessageProxy("PackCamera").TakePhoto();
                                }
                                catch
                                {
                                    PackageHost.WriteError("Votre caméra n'est pas brancher ou le package n'est pas installé");
                                }
                            }
                        }
                    }

                }
                tampon_antepenultieme = e.OldState.DynamicValue.Value; // réactualisation de l'avant avant dernière valeur
            }
        }
    }
}


