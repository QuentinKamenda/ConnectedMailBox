﻿using Constellation;
using Constellation.Package;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.IO;
using System.Timers;

namespace ConstellationPackageConsole2
{
    public class Program : PackageBase
    {
        private double tampon_antepenultieme = 0;                               // initialisation de la variable qui contiendra l'antépénultième  poids dans la boite aux lettres 
        private double reference_poid = 0;                                        // ancien poids validé par le package (on l'initialise juste)

        private Random rnd = new Random();



        [StateObjectLink("BalancePackage", "Balance")]            // On tape "stateobjectlink" puis Tab Tab pour l'autocomplétion du code
        public StateObjectNotifier Balance { get; set; }                    // Ca récupère le State Object (si on veut etre precis: "Sentinel", "Package", "name")

        static void Main(string[] args)
        {
            PackageHost.Start<Program>(args);
        }

        public override void OnStart()
        {
            PackageHost.WriteInfo("Package starting - IsRunning: {0} - IsConnected: {1}", PackageHost.IsRunning, PackageHost.IsConnected);

            tampon_antepenultieme = 0;
            this.Balance.ValueChanged += Balance_ValueChanged;              // On regarde quand la valeur dans CPU change (= évêvnement).


        }

        static int debut_nom_fichier(string chemin)
        {
            int a = 0;
            while (chemin != "1.jpg" && chemin.Length > 0)
            {
                chemin = chemin.Remove(0, 1);
                a++;
            }
            return a - 1;
        }

        static string uri_image()
        {
            string chemin_photo = PackageHost.GetSettingValue<string>("chemin_photo"); // récupère le répertoire où la photo est enrengistrée
            chemin_photo = @"" + chemin_photo;
            // string[] liste_fichier = Directory.GetFiles(@"/var/www/", " * ");
            while (!File.Exists(chemin_photo + "/1.jpg"))   // vérifie que la photo est bien enrengistré
            {

            }
            return chemin_photo + "/1.jpg"; // renvoie le chemin d'accès de la photo
        }

        static string ranger_image()
        {
            string chemin_archive = PackageHost.GetSettingValue<string>("chemin_archive");  // récupère le répertoire de l'archive des photos
            chemin_archive = @"" + chemin_archive;
            string fichier_destination = chemin_archive;
            if (!Directory.Exists(fichier_destination))  // vérifie l'existence du répertoire 
            {
                DirectoryInfo di = Directory.CreateDirectory(chemin_archive); // le créer au besoin
            }
            string nom_image = uri_image();  // récupère le chemin d'accès de la photo qui vient d'être prise
            string adresse_destination = fichier_destination + nom_image.Remove(0, debut_nom_fichier(nom_image)); // créer le chemin d'accès où la photo sera archivée

            string chemin_photo = PackageHost.GetSettingValue<string>("chemin_photo");
            chemin_photo = @"" + chemin_photo;
            File.Move(chemin_photo + "/1.jpg", adresse_destination); // déplace la photo du fichier où elle est enrengistrée, au fichier archive
            string chemin_image = "file://" + chemin_archive; // créer l'uri du fichier photo
            chemin_image = chemin_image + nom_image.Remove(0, debut_nom_fichier(nom_image)); // créer l'uri du fichier photo
            return chemin_image; // renvoie l'uri de la photo
        }



        static void renomer() // cette fonction sert a renommer les photos dans le dossier de l'archive^pour eviter les conflits 
        {
            string chemin_archive = PackageHost.GetSettingValue<string>("chemin_archive"); //recuperation du chemin
            chemin_archive = @"" + chemin_archive;  
            int num_photo = 10;  // nombre de photo que l'on souhaite garder
            string directory = chemin_archive;
            int i = 0;
            if (File.Exists(directory + @"/" + num_photo.ToString() + ".jpg"))  // si la 10ème photo éxiste on la suprime 
            {
                File.Delete(directory + @"/" + num_photo.ToString() + ".jpg");
            }

            var fileCount = (from file in Directory.EnumerateFiles(directory, "*.jpg", SearchOption.AllDirectories) select file).Count(); // compte le nombre de photo dans le dossier archive
            while (i < (fileCount))
            {

                System.IO.File.Move(directory + @"/" + (fileCount - i).ToString() + ".jpg", directory + @"/" + (fileCount + 1 - i).ToString() + ".jpg"); // renome les photos 

                i++;

            }
            // le reste de cette fonction fait la même chose pour les fichiers txt

            int j = 0;
            if (File.Exists(directory + @"/" + num_photo.ToString() + ".txt")) ;
            {
                File.Delete(directory + @"/" + num_photo.ToString() + ".txt");
            }

            var fileCount2 = (from file in Directory.EnumerateFiles(directory, "*.txt", SearchOption.AllDirectories) select file).Count();

            while (j < (fileCount2))
            {

                System.IO.File.Move(directory + @"/" + (fileCount2 - j).ToString() + ".txt", directory + @"/" + (fileCount2 + 1 - j).ToString() + ".txt");

                j++;

            }

        }


        private void Balance_ValueChanged(object sender, StateObjectChangedEventArgs e)
        {
            double Seuil_lettre = PackageHost.GetSettingValue<double>("Seuil_lettre");         // stocke la valeur du poids de la lettre réglé par l'utilisateur (ou par la valeur par défaut)
            double Seuil_magazine = PackageHost.GetSettingValue<double>("Seuil_magazine");     // stocke la valeur du poids du magazine réglé par l'utilisateur (ou par la valeur par défaut)
            double Seuil_colis = PackageHost.GetSettingValue<double>("Seuil_colis");           // stocke la valeur du poids du colis réglé par l'utilisateur (ou par la valeur par défaut)
            bool enable_photo = PackageHost.GetSettingValue<bool>("enable_photo");

            double delta = PackageHost.GetSettingValue<double>("delta");                      // stocke la valeur de l'erreur toléré réglé par l'utilisateur ( ou par la valeur par défaut)


            if (e.IsNew)
            {
                tampon_antepenultieme = e.NewState.DynamicValue.Value;                                 // on garde la première valeur comme tampon de référence
                reference_poid = tampon_antepenultieme;                                          // on garde la première valeur comme poids de référence
            }
            else
            {
                if ((e.NewState.DynamicValue.Value <= e.OldState.DynamicValue.Value + delta && e.NewState.DynamicValue.Value >= e.OldState.DynamicValue.Value - delta) && (e.NewState.DynamicValue.Value <= tampon_antepenultieme + delta && e.NewState.DynamicValue.Value >= tampon_antepenultieme - delta) && (e.NewState.DynamicValue.Value < reference_poid - delta || e.NewState.DynamicValue.Value > reference_poid + delta))
                /* rentre dans la boucle si et seulement si: 
                 *  la nouvelle valeur du poids est similaire aux deux précédentes (plus ou moins l'erreur tolérer, celle d'avant étant oldstate et l'antépénultième étant tampon_antepenultieme)
                 */
                {
                    /*
                     * on  rentre dans l'un des "if" en fonction des seuils réglés par l'utilisateur, le reste du programme étant le même juste l'ordre change
                     */
                    if (Seuil_colis >= Seuil_magazine && Seuil_magazine > Seuil_lettre)
                    {
                        if (e.NewState.DynamicValue.Value - reference_poid >= Seuil_colis) // contient l'instruction lorsque la différence entre le nouveau poids correspond à l'ajout d'un colis
                        {
                            PackageHost.WriteInfo("Vous avez reçus un colis");
                            reference_poid = e.NewState.DynamicValue.Value; // le poids de réference  prend la valeur du poids actuelle
                            if (enable_photo) // rentre dedans si on veut prendre la photo
                            {
                                try // exécute le protocole qui prend la photo, l'enrengistre sur le serveur et envoie le pushbullet
                                {

                                    PackageHost.SendMessage(MessageScope.Create("PackCamera"), "TakePhoto", null); // prend la photo grâce au package caméra
                                    renomer(); // prépare le fichier archive a l'arrivé d'une nouvelle photo

                                    string archive = PackageHost.GetSettingValue<string>("chemin_archive"); // récupère le répertoire de l'archive
                                    archive = @"" + archive;
                                    DateTime Now = DateTime.Now;        // Enregistre (dans la variable "Now" de type DateTime) la date et l'heure actuelle.
                                    string[] lines = { "Photo prise le " + Now.Day + "/" + Now.Month + "/" + Now.Year, "à " + Now.Hour + ":" + Now.Minute + ":" + Now.Second, "Poids :" + e.NewState.DynamicValue.Value + "g" };        //Prépare les lignes à écrire dans le fichier texte
                                    File.WriteAllLines(archive + "/1.txt", lines);      // Ecris les lignes précédentes dans le fichier "1.txt" 

                                    string fichier_image = ranger_image(); // déplace la nouvelle photo dans l'archive et renvoie le chemin d'accès de la nouvelle photo 
                                    PackageHost.SendMessage(MessageScope.Create("PushBullet"), "PushFile", new object[] { fichier_image as System.String, "Vous avez sûrement reçu un colis." as System.String }); //envoie le pushbullet avec la photo
                                }
                                catch
                                {
                                    PackageHost.WriteError("Votre caméra n'est pas branchée ou le package n'est pas installé"); // envoie un message d'erreur dans la console si il y a eu un problème
                                }
                            }
                            else
                            {
                                PackageHost.SendMessage(MessageScope.Create("PushBullet"), "PushNote", new object[] { "Du courrier est arrivé" as System.String, "Vous avez sûrement reçu un colis." as System.String }); // envoie un pusbullet sans la photo
                            }
                        }
                        else if (e.NewState.DynamicValue.Value - reference_poid >= Seuil_magazine) // contient l'instruction lorsque la différence entre le nouveau poids correspond à l'ajout d'un magazine
                        {
                            PackageHost.WriteError("Vous avez reçus un magazine");
                            reference_poid = e.NewState.DynamicValue.Value;
                            if (enable_photo)
                            {
                                try
                                {

                                    PackageHost.SendMessage(MessageScope.Create("PackCamera"), "TakePhoto", null);
                                    renomer();

                                    string archive = PackageHost.GetSettingValue<string>("chemin_archive");
                                    archive = @"" + archive;
                                    DateTime Now = DateTime.Now;
                                    string[] lines = { "Photo prise le " + Now.Day + "/" + Now.Month + "/" + Now.Year, "à " + Now.Hour + ":" + Now.Minute + ":" + Now.Second, "Poids :" + e.NewState.DynamicValue.Value + "g" };
                                    File.WriteAllLines(archive + "/1.txt", lines);

                                    string fichier_image = ranger_image();
                                    PackageHost.SendMessage(MessageScope.Create("PushBullet"), "PushFile", new object[] { fichier_image as System.String, "Vous avez sûrement reçu un magazine." as System.String });
                                }
                                catch
                                {
                                    PackageHost.WriteError("Votre caméra n'est pas branchée ou le package n'est pas installé");
                                }
                            }
                            else
                            {
                                PackageHost.SendMessage(MessageScope.Create("PushBullet"), "PushNote", new object[] { "Du courrier est arrivé" as System.String, "Vous avez sûrement reçu un magazine." as System.String });
                            }
                        }
                        else if (e.NewState.DynamicValue.Value - reference_poid >= Seuil_lettre)  // contient l'instruction lorsque la différence entre le nouveau poids correspond à l'ajout d'une lettre
                        {
                            PackageHost.WriteError("Vous avez reçus une lettre");
                            reference_poid = e.NewState.DynamicValue.Value;
                            if (enable_photo)
                            {
                                try
                                {

                                    PackageHost.SendMessage(MessageScope.Create("PackCamera"), "TakePhoto", null);
                                    renomer();

                                    string archive = PackageHost.GetSettingValue<string>("chemin_archive");
                                    archive = @"" + archive;
                                    DateTime Now = DateTime.Now;
                                    string[] lines = { "Photo prise le " + Now.Day + "/" + Now.Month + "/" + Now.Year, "à " + Now.Hour + ":" + Now.Minute + ":" + Now.Second, "Poids :" + e.NewState.DynamicValue.Value + "g" };
                                    File.WriteAllLines(archive + "/1.txt", lines);

                                    string fichier_image = ranger_image();
                                    PackageHost.SendMessage(MessageScope.Create("PushBullet"), "PushFile", new object[] { fichier_image as System.String, "Vous avez sûrement reçu une lettre." as System.String });
                                }
                                catch
                                {
                                    PackageHost.WriteError("Votre caméra n'est pas branchée ou le package n'est pas installé");
                                }
                            }
                            else
                            {
                                PackageHost.SendMessage(MessageScope.Create("PushBullet"), "PushNote", new object[] { "Du courrier est arrivé" as System.String, "Vous avez sûrement reçu une lettre." as System.String });
                            }
                        }
                        else if (e.NewState.DynamicValue.Value - reference_poid < 0) // contient l'instruction lorsque la différence entre le nouveau poids correspond au retrait d'une partie du courrier
                        {
                            PackageHost.WriteInfo("Du courrier a été retiré");
                            reference_poid = e.NewState.DynamicValue.Value;

                        }
                    }
                    else if (Seuil_colis > Seuil_lettre && Seuil_lettre >= Seuil_magazine)
                    {
                        if (e.NewState.DynamicValue.Value - reference_poid >= Seuil_colis)
                        {
                            PackageHost.WriteInfo("Vous avez reçus un colis");
                            reference_poid = e.NewState.DynamicValue.Value;
                            if (enable_photo)
                            {
                                try
                                {

                                    PackageHost.SendMessage(MessageScope.Create("PackCamera"), "TakePhoto", null);
                                    renomer();

                                    string archive = PackageHost.GetSettingValue<string>("chemin_archive");
                                    archive = @"" + archive;
                                    DateTime Now = DateTime.Now;
                                    string[] lines = { "Photo prise le " + Now.Day + "/" + Now.Month + "/" + Now.Year, "à " + Now.Hour + ":" + Now.Minute + ":" + Now.Second, "Poids :" + e.NewState.DynamicValue.Value + "g" };
                                    File.WriteAllLines(archive + "/1.txt", lines);

                                    string fichier_image = ranger_image();
                                    PackageHost.SendMessage(MessageScope.Create("PushBullet"), "PushFile", new object[] { fichier_image as System.String, "Vous avez sûrement reçu un colis." as System.String });
                                }
                                catch
                                {
                                    PackageHost.WriteError("Votre caméra n'est pas branchée ou le package n'est pas installé");
                                }
                            }
                            else
                            {
                                PackageHost.SendMessage(MessageScope.Create("PushBullet"), "PushNote", new object[] { "Du courrier est arrivé" as System.String, "Vous avez sûrement reçu un colis." as System.String });
                            }
                        }
                        else if (e.NewState.DynamicValue.Value - reference_poid >= Seuil_lettre)
                        {
                            PackageHost.WriteError("Vous avez reçus une lettre");
                            reference_poid = e.NewState.DynamicValue.Value;
                            if (enable_photo)
                            {
                                try
                                {

                                    PackageHost.SendMessage(MessageScope.Create("PackCamera"), "TakePhoto", null);
                                    renomer();

                                    string archive = PackageHost.GetSettingValue<string>("chemin_archive");
                                    archive = @"" + archive;
                                    DateTime Now = DateTime.Now;
                                    string[] lines = { "Photo prise le " + Now.Day + "/" + Now.Month + "/" + Now.Year, "à " + Now.Hour + ":" + Now.Minute + ":" + Now.Second, "Poids :" + e.NewState.DynamicValue.Value + "g" };
                                    File.WriteAllLines(archive + "/1.txt", lines);

                                    string fichier_image = ranger_image();
                                    PackageHost.SendMessage(MessageScope.Create("PushBullet"), "PushFile", new object[] { fichier_image as System.String, "Vous avez sûrement reçu une lettre." as System.String });
                                }
                                catch
                                {
                                    PackageHost.WriteError("Votre caméra n'est pas branchée ou le package n'est pas installé");
                                }
                            }
                            else
                            {
                                PackageHost.SendMessage(MessageScope.Create("PushBullet"), "PushNote", new object[] { "Du courrier est arrivé" as System.String, "Vous avez sûrement reçu une lettre." as System.String });
                            }
                        }
                        else if (e.NewState.DynamicValue.Value - reference_poid >= Seuil_magazine)
                        {
                            PackageHost.WriteError("Vous avez reçus un magazine");
                            reference_poid = e.NewState.DynamicValue.Value;
                            if (enable_photo)
                            {
                                try
                                {

                                    PackageHost.SendMessage(MessageScope.Create("PackCamera"), "TakePhoto", null);
                                    renomer();

                                    string archive = PackageHost.GetSettingValue<string>("chemin_archive");
                                    archive = @"" + archive;
                                    DateTime Now = DateTime.Now;
                                    string[] lines = { "Photo prise le " + Now.Day + "/" + Now.Month + "/" + Now.Year, "à " + Now.Hour + ":" + Now.Minute + ":" + Now.Second, "Poids :" + e.NewState.DynamicValue.Value + "g" };
                                    File.WriteAllLines(archive + "/1.txt", lines);

                                    string fichier_image = ranger_image();
                                    PackageHost.SendMessage(MessageScope.Create("PushBullet"), "PushFile", new object[] { fichier_image as System.String, "Vous avez sûrement reçu un magazine." as System.String });
                                }
                                catch
                                {
                                    PackageHost.WriteError("Votre caméra n'est pas branchée ou le package n'est pas installé");
                                }
                            }
                            else
                            {
                                PackageHost.SendMessage(MessageScope.Create("PushBullet"), "PushNote", new object[] { "Du courrier est arrivé" as System.String, "Vous avez sûrement reçu un magazine." as System.String });
                            }

                        }
                        else if (e.NewState.DynamicValue.Value - reference_poid < 0)
                        {
                            PackageHost.WriteInfo("Du courrier a été retiré");
                            reference_poid = e.NewState.DynamicValue.Value;
                        }
                    }
                    else if (Seuil_magazine > Seuil_colis && Seuil_colis >= Seuil_lettre)
                    {
                        if (e.NewState.DynamicValue.Value - reference_poid >= Seuil_magazine)
                        {
                            PackageHost.WriteInfo("Vous avez reçus un magazine");
                            reference_poid = e.NewState.DynamicValue.Value;
                            if (enable_photo)
                            {
                                try
                                {

                                    PackageHost.SendMessage(MessageScope.Create("PackCamera"), "TakePhoto", null);
                                    renomer();

                                    string archive = PackageHost.GetSettingValue<string>("chemin_archive");
                                    archive = @"" + archive;
                                    DateTime Now = DateTime.Now;
                                    string[] lines = { "Photo prise le " + Now.Day + "/" + Now.Month + "/" + Now.Year, "à " + Now.Hour + ":" + Now.Minute + ":" + Now.Second, "Poids :" + e.NewState.DynamicValue.Value + "g" };
                                    File.WriteAllLines(archive + "/1.txt", lines);

                                    string fichier_image = ranger_image();
                                    PackageHost.SendMessage(MessageScope.Create("PushBullet"), "PushFile", new object[] { fichier_image as System.String, "Vous avez sûrement reçu un magazine." as System.String });
                                }
                                catch
                                {
                                    PackageHost.WriteError("Votre caméra n'est pas branchée ou le package n'est pas installé");
                                }
                            }
                            else
                            {
                                PackageHost.SendMessage(MessageScope.Create("PushBullet"), "PushNote", new object[] { "Du courrier est arrivé" as System.String, "Vous avez sûrement reçu un magazine." as System.String });
                            }
                        }
                        else if (e.NewState.DynamicValue.Value - reference_poid >= Seuil_colis)
                        {
                            PackageHost.WriteError("Vous avez reçus un colis");
                            reference_poid = e.NewState.DynamicValue.Value;
                            if (enable_photo)
                            {
                                try
                                {

                                    PackageHost.SendMessage(MessageScope.Create("PackCamera"), "TakePhoto", null);
                                    renomer();

                                    string archive = PackageHost.GetSettingValue<string>("chemin_archive");
                                    archive = @"" + archive;
                                    DateTime Now = DateTime.Now;
                                    string[] lines = { "Photo prise le " + Now.Day + "/" + Now.Month + "/" + Now.Year, "à " + Now.Hour + ":" + Now.Minute + ":" + Now.Second, "Poids :" + e.NewState.DynamicValue.Value + "g" };
                                    File.WriteAllLines(archive + "/1.txt", lines);

                                    string fichier_image = ranger_image();
                                    PackageHost.SendMessage(MessageScope.Create("PushBullet"), "PushFile", new object[] { fichier_image as System.String, "Vous avez sûrement reçu un colis." as System.String });
                                }
                                catch
                                {
                                    PackageHost.WriteError("Votre caméra n'est pas branchée ou le package n'est pas installé");
                                }
                            }
                            else
                            {
                                PackageHost.SendMessage(MessageScope.Create("PushBullet"), "PushNote", new object[] { "Du courrier est arrivé" as System.String, "Vous avez sûrement reçu un colis." as System.String });
                            }
                        }
                        else if (e.NewState.DynamicValue.Value - reference_poid >= Seuil_lettre)
                        {
                            PackageHost.WriteDebug("Vous avez reçus une lettre");
                            reference_poid = e.NewState.DynamicValue.Value;
                            if (enable_photo)
                            {
                                try
                                {

                                    PackageHost.SendMessage(MessageScope.Create("PackCamera"), "TakePhoto", null);
                                    renomer();

                                    string archive = PackageHost.GetSettingValue<string>("chemin_archive");
                                    archive = @"" + archive;
                                    DateTime Now = DateTime.Now;
                                    string[] lines = { "Photo prise le " + Now.Day + "/" + Now.Month + "/" + Now.Year, "à " + Now.Hour + ":" + Now.Minute + ":" + Now.Second, "Poids :" + e.NewState.DynamicValue.Value + "g" };
                                    File.WriteAllLines(archive + "/1.txt", lines);

                                    string fichier_image = ranger_image();
                                    PackageHost.SendMessage(MessageScope.Create("PushBullet"), "PushFile", new object[] { fichier_image as System.String, "Vous avez sûrement reçu une lettre." as System.String });
                                }
                                catch
                                {
                                    PackageHost.WriteError("Votre caméra n'est pas branchée ou le package n'est pas installé");
                                }
                            }
                            else
                            {
                                PackageHost.SendMessage(MessageScope.Create("PushBullet"), "PushNote", new object[] { "Du courrier est arrivé" as System.String, "Vous avez sûrement reçu une lettre." as System.String });
                            }
                        }
                        else if (e.NewState.DynamicValue.Value - reference_poid < 0)
                        {
                            PackageHost.WriteDebug("Du courrier a été retiré");
                            reference_poid = e.NewState.DynamicValue.Value;
                        }
                    }
                    else if (Seuil_magazine > Seuil_lettre && Seuil_lettre >= Seuil_colis)
                    {
                        if (e.NewState.DynamicValue.Value - reference_poid >= Seuil_magazine)
                        {
                            PackageHost.WriteInfo("Vous avez reçus un magazine");
                            reference_poid = e.NewState.DynamicValue.Value;
                            if (enable_photo)
                            {
                                try
                                {

                                    PackageHost.SendMessage(MessageScope.Create("PackCamera"), "TakePhoto", null);
                                    renomer();

                                    string archive = PackageHost.GetSettingValue<string>("chemin_archive");
                                    archive = @"" + archive;
                                    DateTime Now = DateTime.Now;
                                    string[] lines = { "Photo prise le " + Now.Day + "/" + Now.Month + "/" + Now.Year, "à " + Now.Hour + ":" + Now.Minute + ":" + Now.Second, "Poids :" + e.NewState.DynamicValue.Value + "g" };
                                    File.WriteAllLines(archive + "/1.txt", lines);

                                    string fichier_image = ranger_image();
                                    PackageHost.SendMessage(MessageScope.Create("PushBullet"), "PushFile", new object[] { fichier_image as System.String, "Vous avez sûrement reçu un magazine." as System.String });
                                }
                                catch
                                {
                                    PackageHost.WriteError("Votre caméra n'est pas branchée ou le package n'est pas installé");
                                }
                            }
                            else
                            {
                                PackageHost.SendMessage(MessageScope.Create("PushBullet"), "PushNote", new object[] { "Du courrier est arrivé" as System.String, "Vous avez sûrement reçu un magazine." as System.String });
                            }
                        }
                        else if (e.NewState.DynamicValue.Value - reference_poid >= Seuil_lettre)
                        {
                            PackageHost.WriteError("Vous avez reçus une lettre");
                            reference_poid = e.NewState.DynamicValue.Value;
                            if (enable_photo)
                            {
                                try
                                {

                                    PackageHost.SendMessage(MessageScope.Create("PackCamera"), "TakePhoto", null);
                                    renomer();

                                    string archive = PackageHost.GetSettingValue<string>("chemin_archive");
                                    archive = @"" + archive;
                                    DateTime Now = DateTime.Now;
                                    string[] lines = { "Photo prise le " + Now.Day + "/" + Now.Month + "/" + Now.Year, "à " + Now.Hour + ":" + Now.Minute + ":" + Now.Second, "Poids :" + e.NewState.DynamicValue.Value + "g" };
                                    File.WriteAllLines(archive + "/1.txt", lines);

                                    string fichier_image = ranger_image();
                                    PackageHost.SendMessage(MessageScope.Create("PushBullet"), "PushFile", new object[] { fichier_image as System.String, "Vous avez sûrement reçu une lettre." as System.String });
                                }
                                catch
                                {
                                    PackageHost.WriteError("Votre caméra n'est pas branchée ou le package n'est pas installé");
                                }
                            }
                            else
                            {
                                PackageHost.SendMessage(MessageScope.Create("PushBullet"), "PushNote", new object[] { "Du courrier est arrivé" as System.String, "Vous avez sûrement reçu une lettre." as System.String });
                            }
                        }
                        else if (e.NewState.DynamicValue.Value - reference_poid >= Seuil_colis)
                        {
                            PackageHost.WriteDebug("Vous avez reçus un colis");
                            reference_poid = e.NewState.DynamicValue.Value;
                            if (enable_photo)
                            {
                                try
                                {

                                    PackageHost.SendMessage(MessageScope.Create("PackCamera"), "TakePhoto", null);
                                    renomer();

                                    string archive = PackageHost.GetSettingValue<string>("chemin_archive");
                                    archive = @"" + archive;
                                    DateTime Now = DateTime.Now;
                                    string[] lines = { "Photo prise le " + Now.Day + "/" + Now.Month + "/" + Now.Year, "à " + Now.Hour + ":" + Now.Minute + ":" + Now.Second, "Poids :" + e.NewState.DynamicValue.Value + "g" };
                                    File.WriteAllLines(archive + "/1.txt", lines);

                                    string fichier_image = ranger_image();
                                    PackageHost.SendMessage(MessageScope.Create("PushBullet"), "PushFile", new object[] { fichier_image as System.String, "Vous avez sûrement reçu un colis." as System.String });
                                }
                                catch
                                {
                                    PackageHost.WriteError("Votre caméra n'est pas branchée ou le package n'est pas installé");
                                }
                            }
                            else
                            {
                                PackageHost.SendMessage(MessageScope.Create("PushBullet"), "PushNote", new object[] { "Du courrier est arrivé" as System.String, "Vous avez sûrement reçu un colis." as System.String });
                            }
                        }
                        else if (e.NewState.DynamicValue.Value - reference_poid < 0)
                        {
                            PackageHost.WriteInfo("Du courrier a été retiré");
                            reference_poid = e.NewState.DynamicValue.Value;
                        }
                    }
                    else if (Seuil_lettre > Seuil_magazine && Seuil_magazine >= Seuil_colis)
                    {
                        if (e.NewState.DynamicValue.Value - reference_poid >= Seuil_lettre)
                        {
                            PackageHost.WriteInfo("Vous avez reçus une lettre");
                            reference_poid = e.NewState.DynamicValue.Value;
                            if (enable_photo)
                            {
                                try
                                {

                                    PackageHost.SendMessage(MessageScope.Create("PackCamera"), "TakePhoto", null);
                                    renomer();

                                    string archive = PackageHost.GetSettingValue<string>("chemin_archive");
                                    archive = @"" + archive;
                                    DateTime Now = DateTime.Now;
                                    string[] lines = { "Photo prise le " + Now.Day + "/" + Now.Month + "/" + Now.Year, "à " + Now.Hour + ":" + Now.Minute + ":" + Now.Second, "Poids :" + e.NewState.DynamicValue.Value + "g" };
                                    File.WriteAllLines(archive + "/1.txt", lines);

                                    string fichier_image = ranger_image();
                                    PackageHost.SendMessage(MessageScope.Create("PushBullet"), "PushFile", new object[] { fichier_image as System.String, "Vous avez sûrement reçu une lettre." as System.String });
                                }
                                catch
                                {
                                    PackageHost.WriteError("Votre caméra n'est pas branchée ou le package n'est pas installé");
                                }
                            }
                            else
                            {
                                PackageHost.SendMessage(MessageScope.Create("PushBullet"), "PushNote", new object[] { "Du courrier est arrivé" as System.String, "Vous avez sûrement reçu une lettre." as System.String });
                            }
                        }
                        else if (e.NewState.DynamicValue.Value - reference_poid >= Seuil_magazine)
                        {
                            PackageHost.WriteError("Vous avez reçus un magazine");
                            reference_poid = e.NewState.DynamicValue.Value;
                            if (enable_photo)
                            {
                                try
                                {

                                    PackageHost.SendMessage(MessageScope.Create("PackCamera"), "TakePhoto", null);
                                    renomer();

                                    string archive = PackageHost.GetSettingValue<string>("chemin_archive");
                                    archive = @"" + archive;
                                    DateTime Now = DateTime.Now;
                                    string[] lines = { "Photo prise le " + Now.Day + "/" + Now.Month + "/" + Now.Year, "à " + Now.Hour + ":" + Now.Minute + ":" + Now.Second, "Poids :" + e.NewState.DynamicValue.Value + "g" };
                                    File.WriteAllLines(archive + "/1.txt", lines);

                                    string fichier_image = ranger_image();
                                    PackageHost.SendMessage(MessageScope.Create("PushBullet"), "PushFile", new object[] { fichier_image as System.String, "Vous avez sûrement reçu un magazine." as System.String });
                                }
                                catch
                                {
                                    PackageHost.WriteError("Votre caméra n'est pas branchée ou le package n'est pas installé");
                                }
                            }
                            else
                            {
                                PackageHost.SendMessage(MessageScope.Create("PushBullet"), "PushNote", new object[] { "Du courrier est arrivé" as System.String, "Vous avez sûrement reçu un magazine." as System.String });
                            }
                        }
                        else if (e.NewState.DynamicValue.Value - reference_poid >= Seuil_colis)
                        {
                            PackageHost.WriteDebug("Vous avez reçus un colis");
                            reference_poid = e.NewState.DynamicValue.Value;
                            if (enable_photo)
                            {
                                try
                                {

                                    PackageHost.SendMessage(MessageScope.Create("PackCamera"), "TakePhoto", null);
                                    renomer();

                                    string archive = PackageHost.GetSettingValue<string>("chemin_archive");
                                    archive = @"" + archive;
                                    DateTime Now = DateTime.Now;
                                    string[] lines = { "Photo prise le " + Now.Day + "/" + Now.Month + "/" + Now.Year, "à " + Now.Hour + ":" + Now.Minute + ":" + Now.Second, "Poids :" + e.NewState.DynamicValue.Value + "g" };
                                    File.WriteAllLines(archive + "/1.txt", lines);

                                    string fichier_image = ranger_image();
                                    PackageHost.SendMessage(MessageScope.Create("PushBullet"), "PushFile", new object[] { fichier_image as System.String, "Vous avez sûrement reçu un colis." as System.String });
                                }
                                catch
                                {
                                    PackageHost.WriteError("Votre caméra n'est pas branchée ou le package n'est pas installé");
                                }
                            }
                            else
                            {
                                PackageHost.SendMessage(MessageScope.Create("PushBullet"), "PushNote", new object[] { "Du courrier est arrivé" as System.String, "Vous avez sûrement reçu un colis." as System.String });
                            }
                        }
                        else if (e.NewState.DynamicValue.Value - reference_poid < 0)
                        {
                            PackageHost.WriteInfo("Du courrier a été retiré");
                            reference_poid = e.NewState.DynamicValue.Value;
                        }
                    }
                    else if (Seuil_lettre > Seuil_colis && Seuil_colis > Seuil_magazine)
                    {
                        if (e.NewState.DynamicValue.Value - reference_poid >= Seuil_lettre)
                        {
                            PackageHost.WriteInfo("Vous avez reçus une lettre");
                            reference_poid = e.NewState.DynamicValue.Value;
                            if (enable_photo)
                            {
                                try
                                {

                                    PackageHost.SendMessage(MessageScope.Create("PackCamera"), "TakePhoto", null);
                                    renomer();

                                    string archive = PackageHost.GetSettingValue<string>("chemin_archive");
                                    archive = @"" + archive;
                                    DateTime Now = DateTime.Now;
                                    string[] lines = { "Photo prise le " + Now.Day + "/" + Now.Month + "/" + Now.Year, "à " + Now.Hour + ":" + Now.Minute + ":" + Now.Second, "Poids :" + e.NewState.DynamicValue.Value + "g" };
                                    File.WriteAllLines(archive + "/1.txt", lines);

                                    string fichier_image = ranger_image();
                                    PackageHost.SendMessage(MessageScope.Create("PushBullet"), "PushFile", new object[] { fichier_image as System.String, "Vous avez sûrement reçu une lettre." as System.String });
                                }
                                catch
                                {
                                    PackageHost.WriteError("Votre caméra n'est pas branchée ou le package n'est pas installé");
                                }
                            }
                            else
                            {
                                PackageHost.SendMessage(MessageScope.Create("PushBullet"), "PushNote", new object[] { "Du courrier est arrivé" as System.String, "Vous avez sûrement reçu une lettre." as System.String });
                            }
                        }
                        else if (e.NewState.DynamicValue.Value - reference_poid >= Seuil_colis)
                        {
                            PackageHost.WriteError("Vous avez reçus un colis");
                            reference_poid = e.NewState.DynamicValue.Value;
                            if (enable_photo)
                            {
                                try
                                {

                                    PackageHost.SendMessage(MessageScope.Create("PackCamera"), "TakePhoto", null);
                                    renomer();

                                    string archive = PackageHost.GetSettingValue<string>("chemin_archive");
                                    archive = @"" + archive;
                                    DateTime Now = DateTime.Now;
                                    string[] lines = { "Photo prise le " + Now.Day + "/" + Now.Month + "/" + Now.Year, "à " + Now.Hour + ":" + Now.Minute + ":" + Now.Second, "Poids :" + e.NewState.DynamicValue.Value + "g" };
                                    File.WriteAllLines(archive + "/1.txt", lines);

                                    string fichier_image = ranger_image();
                                    PackageHost.SendMessage(MessageScope.Create("PushBullet"), "PushFile", new object[] { fichier_image as System.String, "Vous avez sûrement reçu un colis." as System.String });
                                }
                                catch
                                {
                                    PackageHost.WriteError("Votre caméra n'est pas branchée ou le package n'est pas installé");
                                }
                            }
                            else
                            {
                                PackageHost.SendMessage(MessageScope.Create("PushBullet"), "PushNote", new object[] { "Du courrier est arrivé" as System.String, "Vous avez sûrement reçu un colis." as System.String });
                            }
                        }
                        else if (e.NewState.DynamicValue.Value - reference_poid >= Seuil_magazine)
                        {
                            PackageHost.WriteDebug("Vous avez reçus un magazine");
                            reference_poid = e.NewState.DynamicValue.Value;
                            if (enable_photo)
                            {
                                try
                                {

                                    PackageHost.SendMessage(MessageScope.Create("PackCamera"), "TakePhoto", null);
                                    renomer();

                                    string archive = PackageHost.GetSettingValue<string>("chemin_archive");
                                    archive = @"" + archive;
                                    DateTime Now = DateTime.Now;
                                    string[] lines = { "Photo prise le " + Now.Day + "/" + Now.Month + "/" + Now.Year, "à " + Now.Hour + ":" + Now.Minute + ":" + Now.Second, "Poids :" + e.NewState.DynamicValue.Value + "g" };
                                    File.WriteAllLines(archive + "/1.txt", lines);

                                    string fichier_image = ranger_image();
                                    PackageHost.SendMessage(MessageScope.Create("PushBullet"), "PushFile", new object[] { fichier_image as System.String, "Vous avez sûrement reçu un magazine." as System.String });
                                }
                                catch
                                {
                                    PackageHost.WriteError("Votre caméra n'est pas branchée ou le package n'est pas installé");
                                }
                            }
                            else
                            {
                                PackageHost.SendMessage(MessageScope.Create("PushBullet"), "PushNote", new object[] { "Du courrier est arrivé" as System.String, "Vous avez sûrement reçu un magazine." as System.String });
                            }
                        }
                        else if (e.NewState.DynamicValue.Value - reference_poid < 0)
                        {
                            PackageHost.WriteInfo("Du courrier a été retiré");
                            reference_poid = e.NewState.DynamicValue.Value;
                        }
                    }
                    else if (Seuil_colis == Seuil_lettre && Seuil_lettre == Seuil_magazine)
                    {
                        PackageHost.WriteDebug("Vous avez reçus du courrier");
                        reference_poid = e.NewState.DynamicValue.Value;
                        if (enable_photo)
                        {
                            try
                            {

                                PackageHost.SendMessage(MessageScope.Create("PackCamera"), "TakePhoto", null);
                                renomer();

                                string archive = PackageHost.GetSettingValue<string>("chemin_archive");
                                archive = @"" + archive;
                                DateTime Now = DateTime.Now;
                                string[] lines = { "Photo prise le " + Now.Day + "/" + Now.Month + "/" + Now.Year, "à " + Now.Hour + ":" + Now.Minute + ":" + Now.Second, "Poids :" + e.NewState.DynamicValue.Value + "g" };
                                File.WriteAllLines(archive + "/1.txt", lines);

                                string fichier_image = ranger_image();
                                PackageHost.SendMessage(MessageScope.Create("PushBullet"), "PushFile", new object[] { fichier_image as System.String, "Vous avez sûrement reçu du courrier." as System.String });
                            }
                            catch
                            {
                                PackageHost.WriteError("Votre caméra n'est pas branchée ou le package n'est pas installé");
                            }
                        }
                        else
                        {
                            PackageHost.SendMessage(MessageScope.Create("PushBullet"), "PushNote", new object[] { "Du courrier est arrivé" as System.String, "Vous avez sûrement reçu du courrier." as System.String });
                        }
                    }
                    else if (e.NewState.DynamicValue.Value - reference_poid < 0)
                    {
                        PackageHost.WriteInfo("Du courrier a été retiré");
                        reference_poid = e.NewState.DynamicValue.Value;
                    }


                }
                tampon_antepenultieme = e.OldState.DynamicValue.Value; // réactualisation de l'avant avant dernière valeur
            }
        }
    }
}


