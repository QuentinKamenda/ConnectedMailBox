﻿import Constellation ## importation 
import subprocess ## écrire dans le terminal 
import os ## écrire dans le terminal 
from picamera import PiCamera # pour la camera Pi
import time ##generer des delais 
import RPi.GPIO as GPIO ##activer les pins






@Constellation.MessageCallback()
def TakePhoto():  ## fonction qui sert a prendre la photo 
    CameraMode = Constellation.GetSetting("Camera_Mode")  ## recuperation du type de camera utilisé dans les settings
    pin = Constellation.GetSetting("pin") ##recuperation de la pin des leds 
    chemin= Constellation.GetSetting("chemin")
    
    if CameraMode == "USBCamera": ## si usb 
        GPIO.output(int(pin), GPIO.HIGH) ## pin 1 etat haut 
        time.sleep(1)  ## 1 sec sleep 
        chemin='fswebcam -r 320x240 -S 3 --jpeg 50 --save '+chemin+'1'+'.jpg'
        os.system(chemin)
        ##os.system('fswebcam -r 320x240 -S 3 --jpeg 50 --save /home/pi/Documents/FileCamera/photo/%H%M%S.jpg')
        time.sleep(1)
        GPIO.output(int(pin), GPIO.LOW) ## eteindre la led 
    
    if CameraMode == "PiCamera": ##si PiCamera
        camera = PiCamera()  ## active la cameraPi sous le nom de "camera" 
        GPIO.output(int(pin), GPIO.HIGH)  ## pin led up 
        time.sleep(1)        
        chemin=chemin+'1'+'.jpg'  ## ecriture de la commande avec un nom different pour l'image 
        camera.capture(chemin)     ## prise de la photo
        time.sleep(1)
        GPIO.output(int(pin), GPIO.LOW)  ## eteind led 
        camera.close()  ##eteindre camera
    Constellation.WriteInfo('Photo prise')
    NumPhoto+=1

@Constellation.MessageCallback()
def Allume(): ## allumer led 
    pin = Constellation.GetSetting("pin") ##numero pin 
    Constellation.WriteInfo('LED Allumée') 
    GPIO.output(int(pin), GPIO.HIGH)  ##état haut pin led 

@Constellation.MessageCallback()
def Eteind(): ##eteindre led 
    pin = Constellation.GetSetting("pin")
    Constellation.WriteInfo('LED Eteinte') 
    GPIO.output(int(pin), GPIO.LOW)  ##état bas pin led 


def OnExit():
    pass

def OnStart():
    pin = Constellation.GetSetting("pin")   ##recuperation numero pin led 
    Constellation.WriteInfo("Hi I'm '%s' and I run on %s. IsConnected = %s | IsStandAlone = %s " % (Constellation.PackageName, Constellation.SentinelName, Constellation.IsConnected, Constellation.IsStandAlone))
    Constellation.WriteInfo("Testing in process...")
    CameraMode = Constellation.GetSetting("Camera_Mode") ## affichage mode de la camera 
    Constellation.WriteInfo(CameraMode)
    GPIO.setmode(GPIO.BCM) ##mode de numerotation pin , le mode BOARD ne semble pas marcher 
    GPIO.setup(int(pin), GPIO.OUT)  ##on defini la pin de led en mode out 
    GPIO.output(int(pin), GPIO.LOW) ##on met son etat a bas au cas ou celle-ci était resté sur haut 



Constellation.Start(OnStart);



